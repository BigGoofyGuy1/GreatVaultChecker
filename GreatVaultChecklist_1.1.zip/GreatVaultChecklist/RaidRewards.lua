RaidRewards = {
    [17] = "iLVL 584 Veteran 1/8",
    [16] = "iLVL 597 Champion 1/8",
    [15] = "iLVL 610 Hero 1/6",
    [14] = "iLVL 623 Myth 1/6"
}

