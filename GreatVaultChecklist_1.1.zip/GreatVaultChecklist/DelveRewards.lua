DelveRewards = {
	[1] = "iLVL 584 Veteran 1/8",
	[2] = "iLVL 584 Veteran 1/8",
    [3] = "iLVL 587 Veteran 2/8",
    [4] = "iLVL 597 Champion 1/8",
    [5] = "iLVL 603 Champion 3/8",
    [6] = "iLVL 606 Champion 4/8",
    [7] = "iLVL 610 Hero 1/6",
    [8] = "iLVL 616 Hero 3/6",
    [9] = "iLVL 616 Hero 3/6",
    [10] = "iLVL 616 Hero 3/6",
    [11] = "iLVL 616 Hero 3/6"
}