MythicRewards = {
    [2] = "iLVL 606 Champion 4/8",
    [3] = "iLVL 610 Hero 1/6",
    [4] = "iLVL 610 Hero 1/6",
    [5] = "iLVL 613 Hero 2/6",
    [6] = "iLVL 613 Hero 2/6",
    [7]	= "iLVL 616 Hero 3/6",
    [8]	= "iLVL 619 Hero 4/6",
    [9]	= "iLVL 619 Hero 4/6",
    [10] = "iLVL 623 Mythic 1/6"
}